const version = "1.8.10";

export default version;
