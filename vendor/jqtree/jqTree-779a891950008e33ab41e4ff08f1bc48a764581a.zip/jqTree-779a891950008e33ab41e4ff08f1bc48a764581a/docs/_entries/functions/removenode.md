---
title: removeNode
name: functions-removenode
---

**function removeNode(node);**

Remove node from the tree.

{% highlight js %}
$('#tree1').tree('removeNode', node);
{% endhighlight %}
