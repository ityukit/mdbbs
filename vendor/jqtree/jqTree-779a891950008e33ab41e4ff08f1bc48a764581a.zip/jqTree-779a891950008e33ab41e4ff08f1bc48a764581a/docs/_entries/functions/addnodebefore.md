---
title: addNodeBefore
name: functions-addnodebefore
---

**function addNodeBefore(newNodeInfo, existingNode);**

Add a new node before this existing node.
