---
title: setState
name: functions-setstate
---

Set the state of the tree: which nodes are open and which one is selected?

See [getState](#functions-getstate) for more information.
