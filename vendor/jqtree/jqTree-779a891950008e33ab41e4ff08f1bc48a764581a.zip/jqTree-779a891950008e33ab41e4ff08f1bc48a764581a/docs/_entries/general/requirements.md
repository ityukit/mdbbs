---
title: Requirements
name: requirements
---

* [jQuery](http://jquery.com) 1.9+, 2.x or 3.x
