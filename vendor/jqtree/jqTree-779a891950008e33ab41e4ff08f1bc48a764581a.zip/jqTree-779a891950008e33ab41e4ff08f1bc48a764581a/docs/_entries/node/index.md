---
title: Node functions
name: node-functions
section: true
---

You can access a node using for example [getNodeById](#functions-getnodebyid) function:

{% highlight js %}
var node = $('#tree1').tree('getNodeById', 123);
{% endhighlight %}

The Node object has the following properties and functions:
