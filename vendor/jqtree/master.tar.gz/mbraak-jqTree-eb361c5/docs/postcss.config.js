module.exports = {
    plugins: [
        require("autoprefixer"),
        require("tailwindcss/nesting"),
        require("tailwindcss"),
    ],
};
