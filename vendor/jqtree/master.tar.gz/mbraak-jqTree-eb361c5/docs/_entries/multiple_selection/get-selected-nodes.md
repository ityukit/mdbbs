---
title: getSelectedNodes
name: multiple-selection-get-selected-nodes
---

Get the selected nodes. Return an array of nodes

{% highlight js %}
var node = $tree.tree('getSelectedNodes');
{% endhighlight %}
